package com.xkiluaa.rat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class FingerprintActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_fingerprint);

        ImageView fp = findViewById(R.id.img_fingerprint);
        Animation pulse = AnimationUtils.loadAnimation(this, R.anim.pulse);
        fp.startAnimation(pulse);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(FingerprintActivity.this, MainActivity.class));
                finish();
            }
        }, 2000);
    }
}